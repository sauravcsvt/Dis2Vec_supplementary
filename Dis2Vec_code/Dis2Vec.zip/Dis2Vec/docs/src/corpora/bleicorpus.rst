:mod:`corpora.bleicorpus` -- Corpus in Blei's LDA-C format
==========================================================

.. automodule:: gensim.corpora.bleicorpus
    :synopsis: Corpus in Blei's LDA-C format
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
