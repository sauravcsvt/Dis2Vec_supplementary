:mod:`corpora.dictionary` -- Construct word<->id mappings
==========================================================

.. automodule:: gensim.corpora.dictionary
    :synopsis: Construct word<->id mappings
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
