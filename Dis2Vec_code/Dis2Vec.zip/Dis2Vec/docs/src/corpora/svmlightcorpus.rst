:mod:`corpora.svmlightcorpus` -- Corpus in SVMlight format
==================================================================

.. automodule:: gensim.corpora.svmlightcorpus
    :synopsis: Corpus in SVMlight format
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
