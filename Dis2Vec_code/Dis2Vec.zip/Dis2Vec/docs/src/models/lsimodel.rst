:mod:`models.lsimodel` -- Latent Semantic Indexing
======================================================

.. automodule:: gensim.models.lsimodel
    :synopsis: Latent Semantic Indexing
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
