:mod:`models.logentropy_model` -- LogEntropy model
======================================================

.. automodule:: gensim.models.logentropy_model
    :synopsis: LogEntropy model
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
