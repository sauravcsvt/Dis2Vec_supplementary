:mod:`models.wrappers` -- Package for transformation models via external programs
=================================================================================

.. automodule:: gensim.models.wrappers
    :synopsis: Package for transformation models via external programs
    :members:
    :inherited-members:

