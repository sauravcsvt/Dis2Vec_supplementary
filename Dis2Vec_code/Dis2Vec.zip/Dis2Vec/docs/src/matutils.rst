:mod:`matutils` -- Math utils
==============================

.. automodule:: gensim.matutils
    :synopsis: Math utils
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
