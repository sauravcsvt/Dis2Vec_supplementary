.. toctree::
   :hidden:
   :maxdepth: 1

   intro
   install
   tutorial
   distributed
   support
   wiki
   apiref
